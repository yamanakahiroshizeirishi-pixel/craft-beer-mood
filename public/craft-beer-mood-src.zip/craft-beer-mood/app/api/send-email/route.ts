import { NextRequest, NextResponse } from "next/server";
import nodemailer from "nodemailer";
import { generateMoodEmail } from "@/lib/emailTemplate";

export async function POST(request: NextRequest) {
  try {
    const { to, name } = await request.json();

    if (!to || !name) {
      return NextResponse.json(
        { error: "宛先メールアドレスと名前は必須です" },
        { status: 400 }
      );
    }

    const baseUrl =
      process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000";

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    const htmlContent = generateMoodEmail(baseUrl, name);

    await transporter.sendMail({
      from: `"クラフトビールセレクション 🍺" <${process.env.GMAIL_USER}>`,
      to,
      subject: `🍺 ${name}さん、今日の気分に合うクラフトビールは？`,
      html: htmlContent,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Email send error:", error);
    return NextResponse.json(
      { error: "メールの送信に失敗しました" },
      { status: 500 }
    );
  }
}
